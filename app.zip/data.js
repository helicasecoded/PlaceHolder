// Naya exercise/mission add karna ho to yahin add karo. Koi aur file badalne ki zaroorat nahi.
const ST=[50,50,0,10,10,-10,-10,6,0,-6,0];
const PU=[62,70,-65,0,0,0,0,65,65,65,65];
const PG=[50,50,0,25,170,-25,-170,15,0,-15,0];
const PA=[50,50,0,25,170,-90,-90,15,0,-15,0];
const KA=[50,50,0,10,10,-10,-10,6,0,-85,-85];
export const DATA={
ex:{
squat:{n:"Squat",d:"Pair kandhe-barabar, kamar peeche, ghutne 90° tak. Seena upar.",reps:12,u:"reps",st:{strength:2,endurance:1},kf:[ST,[50,59,0,90,90,-90,-90,55,0,-55,0]]},
pushup:{n:"Pushup",d:"Kamar seedhi line mein, seena zameen ke paas tak. Camera side se rakho.",reps:8,u:"reps",st:{strength:3,power:1},kf:[PU,[62,76,-72,-60,0,-60,0,72,72,72,72]]},
lunge:{n:"Lunge",d:"Ek pair aage, peeche ka ghutna zameen ke paas.",reps:10,u:"reps",st:{strength:1,agility:2},kf:[ST,[50,60,0,10,10,-10,-10,65,0,-30,-80]]},
jj:{n:"Jumping Jack",d:"Haath sir ke upar, pair chaude, phir wapas.",reps:20,u:"reps",st:{endurance:2,agility:1,speed:1},kf:[ST,[50,50,0,150,160,-150,-160,30,30,-30,-30]]},
plank:{n:"Plank",d:"Kohni pe, kamar seedhi. Side se camera rakho. Seconds count hote hain.",reps:30,u:"sec",st:{strength:2,endurance:2},kf:[PU,[62,71,-66,0,0,0,0,66,66,66,66]]},
kick:{n:"Kick drill",d:"Guard upar, kick kamar ki height tak, sambhal kar wapas stance.",reps:10,u:"kick",lg:"kick",st:{combat:3,power:2,agility:1},kf:[ST,KA]},
box:{n:"Boxing: Jab/Cross",d:"Guard chin ke paas, punch seedha, phir turant guard.",reps:20,u:"punch",lg:"punch",st:{combat:3,speed:1,reflex:1},kf:[PG,PA]},
},
// goal: [naam, 5 training days ki list]. Hafte mein Wed aur Sun rest.
goals:{
fatloss:["Weight loss",[["jj","squat","lunge","plank"],["pushup","jj","squat"],["lunge","jj","plank"],["squat","pushup","jj"],["jj","lunge","plank","squat"]]],
muscle:["Muscle gain",[["pushup","squat","plank"],["lunge","squat","pushup"],["pushup","plank"],["squat","lunge","pushup"],["pushup","squat","plank","lunge"]]],
lean:["Lean + fit",[["pushup","squat","jj"],["lunge","plank","jj"],["squat","pushup","plank"],["jj","lunge","pushup"],["squat","plank","jj","pushup"]]],
stamina:["Stamina",[["jj","lunge","squat"],["jj","plank"],["jj","squat","lunge","plank"],["jj","pushup"],["jj","lunge","plank"]]],
flex:["Flexibility + Stand Tall",[["lunge","plank"],["squat","lunge"],["plank","lunge"],["squat","plank"],["lunge","squat","plank"]]],
fighter:["Fighter",[["box","jj","plank"],["kick","box","squat"],["kick","lunge","jj"],["kick","box","plank"],["box","kick","jj","pushup"]]]
},
st:{
cat:{n:"Cat-Cow",d:"Haath-ghutne par, saans ke saath peeth ko upar-neeche mod'o.",s:40},
cobra:{n:"Cobra stretch",d:"Pet ke bal letkar seena dheere upar uthao, kandhe peeche, gardan lambi.",s:30},
child:{n:"Child pose",d:"Ghutno par baith kar haath aage failao, peeth aur kandhe dheele chhodo.",s:40},
ham:{n:"Hamstring stretch",d:"Ek pair aage, peeth seedhi, kamar se aage jhuko. Pair ki peeth mein halka khinchav.",s:30},
hip:{n:"Hip flexor stretch",d:"Lunge position mein kulhe aage dhakelo, seena upar.",s:30},
chest:{n:"Doorway chest opener",d:"Darwaze par kohni 90° par rakho, seena dheere aage.",s:30},
wall:{n:"Wall angel",d:"Deewar se peeth aur sar lagao, haath upar-neeche slide karo.",s:40},
chin:{n:"Chin tuck",d:"Thodi ko seedhe peeche kheencho, gardan lambi mehsoos ho.",s:20},
reach:{n:"Overhead reach",d:"Haath upar, ungliyan jodo, poori body ko upar kheencho.",s:30},
side:{n:"Side bend",d:"Haath upar, ek taraf jhuko, phir doosri taraf.",s:30},
hang:{n:"Dead hang",d:"Bar ya majboot pakad se latko, kandhe dheele. Bar na ho to 'Fist squeeze' karo.",s:20},
fist:{n:"Fist squeeze",d:"Rubber ball ya towel ko poori taakat se bhincho aur chhodo.",s:30},
towel:{n:"Towel wring",d:"Geele towel ko dono haathon se nichodo, dono disha mein.",s:30},
carry:{n:"Bag carry",d:"Bhaari bag ya paani ki balti pakad kar seedhe chalo.",s:40},
focus:{n:"Deep focus",d:"Phone door, ek hi kaam, notifications band.",s:1500}
},
routines:{
tall:{n:"Stand Tall",d:"Posture aur flexibility. Height nahi badhata, lekin seedhe khade hone par poori asal height dikhti hai.",items:["reach","chin","wall","cat","cobra","child","hip","ham","chest","side"],stats:{flex:15,looks:6,agility:4}},
grip:{n:"Grip training",d:"Haath aur kalai ki pakad.",items:["hang","fist","towel","carry"],stats:{grip:15,strength:4}},
focus:{n:"Focus timer",d:"25 min deep work, phone door.",items:["focus"],stats:{focus:20,mind:5}}
},
missions:[
{n:"Grooming",t:[["Face wash + moisturizer (subah)","Skin glow ka base",{looks:10}],["Sunscreen lagao","Bahar jaane se pehle",{looks:10}],["Raat ko face wash + moisturizer","Beard ke neeche bhi",{looks:10}]]},
{n:"Style",t:[["Kapde press karo, fit check karo","Na dheele na tight",{looks:10}],["Joote aur belt saaf rakho","Log pehle yehi dekhte hain",{looks:10}]]},
{n:"Baat-cheet",t:[["Ek naye insaan se 2 min baat karo","Dukaandaar, padosi, colleague",{talk:20}],["Kisi ki sachchi tareef karo","Specific bolo",{talk:15}],["Kisi se sawaal poocho, dhyan se suno","Beech mein mat toko",{talk:15}]]},
{n:"Confidence",t:[["2 min seedhe khade ho kar posture practice","Kandhe peeche",{mind:10}],["Sheeshe mein 1 min eye contact","Pehle awkward, phir normal",{mind:10}],["Ek chhota darr wala kaam karo","Jo kal tak taal rahe the",{mind:25}]]},
{n:"Character",t:[["Jo wada kiya tha aaj nibhao","Bharosa isi se banta hai",{char:15}],["Kisi ki bina maange madad karo","Chhoti si bhi",{char:12}],["Galti ho to seedha maan lo, bahana nahi","Imandari",{char:15}],["Gussa aaye to 10 second ruk kar jawab do","Self-control",{char:12}],["Aaj kisi ki burai ya gossip nahi","Doosre ki peeth peeche bhi izzat",{char:10}],["Raat ko 3 cheezein likho jinke liye shukr hai","Gratitude",{char:8,mind:4}]]},
{n:"Dimaag",t:[["15 min kuch naya padho","Skill ya book",{mind:15}],["5 min kuch yaad karo, kal bina dekhe likho","Active recall sabse achha tareeka",{memory:15}],["5 min shaant baith kar saans par dhyan","Calm vibe",{mind:10}],["Raat ko likho: aaj kya accha kiya","Self-respect badhta hai",{mind:10}],["3 litre paani piyo","Glow + energy",{endurance:5,looks:5}]]}
],
challenges:["Aaj kisi ko bina maange help karo.","Aaj doosre ko pehle bolne do, phir dhyan se jawab do.","Aaj eye level par natural light mein photo lo.","Aaj ek sach wali aur thodi funny baat bolo.","Aaj 'thank you' ke saath ek line extra bolo.","Aaj dheere bolo, har sentence ke baad pause lo.","Aaj ek naya style try karo."]
};
