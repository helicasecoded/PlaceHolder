// Naya exercise/mission add karna ho to yahin add karo. Koi aur file badalne ki zaroorat nahi.
const ST=[50,50,0,10,10,-10,-10,6,0,-6,0];
const PU=[62,70,-65,0,0,0,0,65,65,65,65];
const PG=[50,50,0,25,170,-25,-170,15,0,-15,0];
const PA=[50,50,0,25,170,-90,-90,15,0,-15,0];
const KA=[50,50,0,10,10,-10,-10,6,0,-85,-85];
export const DATA={
ex:{
squat:{n:"Squat",d:"Pair kandhe-barabar, kamar peeche, ghutne 90° tak. Seena upar.",reps:12,u:"reps",st:{strength:2,endurance:1},kf:[ST,[50,59,0,90,90,-90,-90,55,0,-55,0]]},
pushup:{n:"Pushup",d:"Kamar seedhi line mein, seena zameen ke paas tak. Camera side se rakho.",reps:8,u:"reps",st:{strength:3,power:1},kf:[PU,[62,76,-72,-60,0,-60,0,72,72,72,72]]},
lunge:{n:"Lunge",d:"Ek pair aage, peeche ka ghutna zameen ke paas.",reps:10,u:"reps",st:{strength:1,agility:2},kf:[ST,[50,60,0,10,10,-10,-10,65,0,-30,-80]]},
jj:{n:"Jumping Jack",d:"Haath sir ke upar, pair chaude, phir wapas.",reps:20,u:"reps",st:{endurance:2,agility:1,speed:1},kf:[ST,[50,50,0,150,160,-150,-160,30,30,-30,-30]]},
plank:{n:"Plank",d:"Kohni pe, kamar seedhi. Side se camera rakho. Seconds count hote hain.",reps:30,u:"sec",st:{strength:2,endurance:2},kf:[PU,[62,71,-66,0,0,0,0,66,66,66,66]]},
box:{n:"Boxing: Jab/Cross",d:"Guard chin ke paas, punch seedha, phir turant guard.",reps:20,u:"punch",lg:"punch",st:{combat:3,speed:1,reflex:1},kf:[PG,PA]},
muaythai:{n:"Muay Thai: Teep/Kick",d:"Guard upar, kick kamar ki height tak.",reps:10,u:"kick",lg:"kick",st:{combat:3,power:2},kf:[ST,KA]},
karate:{n:"Karate: Mae-geri",d:"Seedha front kick, sambhal kar wapas stance.",reps:10,u:"kick",lg:"kick",st:{combat:3,agility:1},kf:[ST,KA]},
tkd:{n:"Taekwondo: Ap chagi",d:"Ghutna uthao, kick ko kamar se upar le jao.",reps:10,u:"kick",lg:"kick",st:{combat:2,agility:2,power:1},kf:[ST,KA]}
},
// goal: [naam, 5 training days ki list]. Hafte mein Wed aur Sun rest.
goals:{
fatloss:["Weight loss",[["jj","squat","lunge","plank"],["pushup","jj","squat"],["lunge","jj","plank"],["squat","pushup","jj"],["jj","lunge","plank","squat"]]],
muscle:["Muscle gain",[["pushup","squat","plank"],["lunge","squat","pushup"],["pushup","plank"],["squat","lunge","pushup"],["pushup","squat","plank","lunge"]]],
lean:["Lean + fit",[["pushup","squat","jj"],["lunge","plank","jj"],["squat","pushup","plank"],["jj","lunge","pushup"],["squat","plank","jj","pushup"]]],
stamina:["Stamina",[["jj","lunge","squat"],["jj","plank"],["jj","squat","lunge","plank"],["jj","pushup"],["jj","lunge","plank"]]],
flex:["Flexibility + control",[["lunge","plank"],["squat","lunge"],["plank","lunge"],["squat","plank"],["lunge","squat","plank"]]],
fighter:["Fighter",[["box","jj","plank"],["muaythai","box","squat"],["karate","lunge","jj"],["tkd","box","plank"],["box","muaythai","jj","pushup"]]]
},
missions:[
{n:"Grooming",t:[["Face wash + moisturizer (subah)","Skin glow ka base",{looks:10}],["Sunscreen lagao","Bahar jaane se pehle",{looks:10}],["Raat ko face wash + moisturizer","Beard ke neeche bhi",{looks:10}]]},
{n:"Style",t:[["Kapde press karo, fit check karo","Na dheele na tight",{looks:10}],["Joote aur belt saaf rakho","Log pehle yehi dekhte hain",{looks:10}]]},
{n:"Baat-cheet",t:[["Ek naye insaan se 2 min baat karo","Dukaandaar, padosi, colleague",{talk:20}],["Kisi ki sachchi tareef karo","Specific bolo",{talk:15}],["Kisi se sawaal poocho, dhyan se suno","Beech mein mat toko",{talk:15}]]},
{n:"Confidence",t:[["2 min seedhe khade ho kar posture practice","Kandhe peeche",{mind:10}],["Sheeshe mein 1 min eye contact","Pehle awkward, phir normal",{mind:10}],["Ek chhota darr wala kaam karo","Jo kal tak taal rahe the",{mind:25}]]},
{n:"Dimaag",t:[["15 min kuch naya padho","Skill ya book",{mind:15}],["5 min shaant baith kar saans par dhyan","Calm vibe",{mind:10}],["Raat ko likho: aaj kya accha kiya","Self-respect badhta hai",{mind:10}],["3 litre paani piyo","Glow + energy",{endurance:5,looks:5}]]}
],
challenges:["Aaj kisi ko bina maange help karo.","Aaj doosre ko pehle bolne do, phir dhyan se jawab do.","Aaj eye level par natural light mein photo lo.","Aaj ek sach wali aur thodi funny baat bolo.","Aaj 'thank you' ke saath ek line extra bolo.","Aaj dheere bolo, har sentence ke baad pause lo.","Aaj ek naya style try karo."]
};
