import {DATA} from "./data.js";
const $=s=>document.querySelector(s),KEY="alagdikho_v2",T=()=>new Date().toLocaleDateString("en-CA");
const STATS={speed:"Speed",reflex:"Reflex",agility:"Agility",strength:"Strength",power:"Power",endurance:"Endurance",combat:"Combat",looks:"Looks",talk:"Talk",mind:"Mind",grip:"Grip",flex:"Flexibility",memory:"Memory",focus:"Focus",char:"Character"};
let S={p:null,xp:{},streak:0,last:"",day:"",done:{},photos:[],best:0,tab:"home",log:{},sub:""};
try{Object.assign(S,JSON.parse(localStorage.getItem(KEY)||"{}"))}catch(e){}
if(S.day!==T()){S.day=T();S.done={}}if(S.p&&!DATA.goals[S.p.goal])S.p=null;if(S.tab==="looks")S.tab="more";
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const lv=x=>Math.floor(Math.sqrt((x||0)/20))+1;
const total=()=>Object.values(S.xp).reduce((a,b)=>a+b,0);
const rank=()=>{const a=Object.keys(STATS).reduce((s,k)=>s+lv(S.xp[k]),0)/Object.keys(STATS).length;return a<1.6?"E":a<2.2?"D":a<3?"C":a<4?"B":a<5.5?"A":"S"};
function award(m){const b={speed:["speed","reflex","agility"],strength:["strength","power","endurance","combat","grip"],mind:["memory","focus","mind","talk"]}[S.p&&S.p.path]||[];
 for(const k in m)S.xp[k]=(S.xp[k]||0)+Math.round(m[k]*(b.includes(k)?1.25:1));
 if(S.last!==T()){const y=new Date();y.setDate(y.getDate()-1);S.streak=S.last===y.toLocaleDateString("en-CA")?S.streak+1:1;S.last=T()}S.log[T()]=(S.log[T()]||0)+1;save()}
const mins=()=>S.p.min||30;
const stMin=()=>S.p.goal==="flex"?Math.round(mins()*.4):mins()>=45?6:mins()>=30?5:3;
function plan(d){const map={1:0,2:1,4:2,5:3,6:4},sm=stMin();if(!(d in map))return {rest:1,sm:sm+3,ex:[]};
 const m=[1,1.5,2][S.p.level];let ids=[...DATA.goals[S.p.goal][1][map[d]]];if(S.p.path==="speed")ids.push("jj");if(S.p.path==="strength")ids.push("pushup");
 ids=[...new Set(ids)];const blocks=Math.max(1,Math.floor((mins()-sm)/4)),n=Math.min(ids.length,blocks),tot=blocks*3;
 return {sm,ex:ids.slice(0,n).map((id,i)=>({id,n:Math.round(DATA.ex[id].reps*m),sets:Math.min(5,Math.floor(tot/n)+(i<tot%n?1:0))}))}}
const rtBtn=(k,m)=>`<div class="card row"><div><b>${DATA.routines[k].n}</b><div class="sub">${m} min · ${DATA.routines[k].d}</div></div><button class="btn s" data-a="rt" data-id="${k}" data-m="${m}">Start</button></div>`;
const exBtn=(x)=>`<div class="card row"><div><b>${DATA.ex[x.id].n}</b><div class="sub">${x.sets?x.sets+" sets × ":""}${x.n} ${DATA.ex[x.id].u}</div></div><button class="btn s" data-a="train" data-id="${x.id}">Start</button></div>`;
const IC={home:'<path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z"/>',plan:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',train:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',missions:'<path d="M5 12l5 5L20 7"/>',stats:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',more:'<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>'};
const TABS=[["home","Home"],["plan","Plan"],["train","Train"],["missions","Missions"],["stats","Stats"],["more","More"]];
const setRank=()=>{$("#rk").innerHTML=S.p?`<span>RANK</span><b>${rank()}</b>`:""};
function render(){
 $("#tb").innerHTML=TABS.map(([k,n])=>`<button data-a="tab" data-id="${k}" class="${S.tab===k?"on":""}"><svg viewBox="0 0 24 24">${IC[k]}</svg>${n}</button>`).join("");
 setRank();
 const v=$("#v");if(!S.p){v.innerHTML=onboard();return}
 v.innerHTML=(({home,plan:planV,train,missions,stats,more})[S.tab]||home)();
 if(S.tab==="stats")radar()}
function onboard(){const o=(o)=>Object.entries(o).map(([k,n])=>`<option value="${k}">${n}</option>`).join("");
 return `<div class="hero"><span class="kj">進化</span><h2>Shinka: roz thoda evolve karo</h2><p class="sub">Body, looks, baat-cheet aur dimaag, sab ek jagah. Pehle apna goal chuno, uske hisaab se plan banega.</p></div><div class="card" style="margin-top:16px">
 <label>Body goal<select id="g">${o(Object.fromEntries(Object.entries(DATA.goals).map(([k,g])=>[k,g[0]])))}</select></label>
 <label>Level<select id="l"><option value="0">Beginner</option><option value="1">Intermediate</option><option value="2">Advanced</option></select></label>
 <label>Path<select id="pa"><option value="bal">Balanced</option><option value="speed">Speed path (speed, reflex, agility)</option><option value="strength">Strength path (strength, power, combat, grip)</option><option value="mind">Brain path (memory, focus, talk)</option></select></label>
 <label>Roz kitna time doge<select id="tmo"><option value="15">15 min</option><option value="30" selected>30 min</option><option value="45">45 min</option><option value="60">60 min</option></select></label><p class="sub">Dard ya chot ho to ruk jao aur doctor se poocho. Ye app doctor ya coach ki jagah nahi leta.</p>
 <button class="btn w" data-a="start">Shuru karo</button></div>`}
function home(){const p=plan(new Date().getDay()),all=DATA.missions.flatMap((c,i)=>c.t.map((_,j)=>i+"_"+j)),dn=all.filter(k=>S.done[k]).length;
 return `<div class="stats"><div class="stat"><b>${S.streak}</b><span>DIN STREAK</span></div><div class="stat"><b>${dn}/${all.length}</b><span>MISSIONS</span></div><div class="stat"><b>${Object.values(S.xp).reduce((a,b)=>a+b,0)}</b><span>TOTAL XP</span></div></div>
 <h2>Aaj ka workout</h2><div class="sub">Tumhara roz ka time: ${mins()} min</div>${p.rest?'<div class="card sub">Aaj rest day. Halki stretching aur khoob paani.</div>':p.ex.map(exBtn).join("")}<h2>Stand Tall</h2>${rtBtn("tall",p.sm)}${S.p.path==="strength"?rtBtn("grip",3):""}<h2>Brain Lab</h2><div class="card row"><div><b>Memory, focus, flashcards</b><div class="sub">Dimaag ki roz ki practice</div></div><button class="btn s" data-a="goto" data-id="brain">Open</button></div>
 <h2>Stand-out challenge</h2><div class="card">${DATA.challenges[new Date().getDay()]}</div>`}
function planV(){const names=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
 return `<h2>${DATA.goals[S.p.goal][0]}: hafte ka plan</h2><label>Roz ka time<select id="tm">${[15,30,45,60].map(m=>`<option ${mins()===m?"selected":""} value="${m}">${m} min</option>`).join("")}</select></label>`+[1,2,3,4,5,6,0].map(d=>{const p=plan(d);return `<div class="card"><b>${names[d]}</b><div class="sub">${p.rest?"Rest + Stand Tall "+p.sm+" min":p.ex.map(x=>DATA.ex[x.id].n+" "+x.sets+"×"+x.n).join(", ")+" + Stand Tall "+p.sm+" min"}</div></div>`}).join("")+`<button class="btn o w" data-a="redo">Goal badlo</button>`}
function train(){return `<h2>Camera trainer</h2><p class="sub">Phone 2-3 meter door, poori body dikhe. Video phone se bahar nahi jaati.</p>`+Object.keys(DATA.ex).map(id=>exBtn({id,n:DATA.ex[id].reps})).join("")+
 `<h2>Stand Tall + Grip</h2>`+rtBtn("tall",10)+rtBtn("grip",3)+`<h2>Reflex drill</h2><div class="card"><div id="rx" class="sub">5 round. Hara circle dikhte hi tap karo.</div><div id="ar" class="tgt"></div><button class="btn w" data-a="rx">Start</button></div>`}
function missions(){return DATA.missions.map((c,i)=>`<h2>${c.n}</h2>`+c.t.map((t,j)=>{const k=i+"_"+j,d=S.done[k];return `<button class="task ${d?"done":""}" data-a="m" data-id="${k}"><span class="box">${d?"✓":""}</span><span><b>${t[0]}</b><div class="sub">${t[1]}</div></span></button>`}).join("")).join("")}
function stats(){return report()+"<h2>Consistency (12 hafte)</h2>"+heat()+"<h2>Badges</h2>"+badges()+`<h2>Tumhare stats</h2><canvas id="rd" width="320" height="300" style="width:100%"></canvas>`+Object.entries(STATS).map(([k,n])=>`<div class="card"><div class="row"><b>${n}</b><span>Lv ${lv(S.xp[k])} · ${S.xp[k]||0} XP</span></div><div class="bar"><i style="width:${Math.min(100,((S.xp[k]||0)%(20*lv(S.xp[k])**2))/(20*(2*lv(S.xp[k])+1))*100)}%"></i></div></div>`).join("")}
function radar(){const c=$("#rd").getContext("2d"),ks=Object.keys(STATS),cx=160,cy=150,R=100,col=getComputedStyle(document.body).color;c.strokeStyle=col;c.fillStyle=col;c.globalAlpha=.25;
 for(let r=1;r<=4;r++){c.beginPath();ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571;c.lineTo(cx+R*r/4*Math.cos(a),cy+R*r/4*Math.sin(a))});c.closePath();c.stroke()}
 c.globalAlpha=1;c.font="11px system-ui";c.textAlign="center";ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571;c.fillText(STATS[k],cx+(R+22)*Math.cos(a),cy+(R+22)*Math.sin(a)+4)});
 c.beginPath();ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571,r=R*Math.min(1,lv(S.xp[k])/10);c.lineTo(cx+r*Math.cos(a),cy+r*Math.sin(a))});c.closePath();c.fillStyle="rgba(215,38,61,.35)";c.fill();c.strokeStyle="#d7263d";c.lineWidth=2;c.stroke()}
function looks(){return `<h2>Photo progress</h2><p class="sub">Photos sirf is phone mein save hoti hain. Har 30 din mein ek photo lo, same light aur same angle.</p>
 <label class="btn w" style="display:block;text-align:center">Photo add karo<input id="ph" type="file" accept="image/*" hidden></label>
 <div class="g" style="margin-top:10px">${S.photos.map(p=>`<div><img class="ph" src="${p.s}" alt=""><div class="sub">${p.d}</div></div>`).join("")}</div>`}
document.addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(!b)return;const a=b.dataset.a,id=b.dataset.id;
 if(a==="tab"){stop(true);stopRt();stopG();S.tab=id;S.sub="";save();render()}
 else if(a==="start"){S.p={goal:$("#g").value,level:+$("#l").value,path:$("#pa").value,min:+$("#tmo").value};save();render()}
 else if(a==="sub"){stopG();S.sub=id;render()}else if(a==="share")share();else if(a==="export")exp();else if(a==="rt")startRt(id,+b.dataset.m);else if(a==="skip"&&rt)rt.t=1;else if(a==="rtstop")finRt(false);else if(a==="hadd"){const h=parseFloat($("#hc").value);if(h>100&&h<250){(S.hl=S.hl||[]).push({d:T(),h});save();render()}}else if(a==="goto"){S.tab="more";S.sub=id;render()}else if(a==="g")startG(id)
 else if(a==="cell"&&G.k==="seq"&&!G.lock){const c=+id;b.classList.add("lit");setTimeout(()=>b.classList.remove("lit"),150);if(G.seq[G.inp]!==c)return endG(G.lvl-1);G.inp++;if(G.inp===G.seq.length){G.lock=true;G.to.push(setTimeout(nextSeq,700))}}
 else if(a==="nchk"){if($("#nm").value.trim()===G.v){G.n++;nextNum()}else endG(G.n-1)}
 else if(a==="mchk"){const v=$("#mi").value.trim();if(v!==""&&+v===G.ans)G.sc++;nextQ()}
 else if(a==="cadd"){const q=$("#cq").value.trim(),an=$("#ca").value.trim();if(q&&an){(S.cards=S.cards||[]).push({q,a:an,b:0,due:T()});save();render()}}
 else if(a==="rev")review();
 else if(a==="show"){const c=G.q[G.i];$("#ans").innerHTML=`<div class="card" style="text-align:center">${c.a}</div>`;b.outerHTML='<div class="g"><button class="btn o" data-a="rg" data-id="0">Bhool gaya</button><button class="btn" data-a="rg" data-id="1">Yaad tha</button></div>'}
 else if(a==="rg"){const c=G.q[G.i];if(id==="1"){G.ok++;c.b=Math.min(5,(c.b||0)+1)}else c.b=0;c.due=dk(-[0,1,2,4,8,16][c.b]);G.i++;save();revNext()}
 else if(a==="redo"){S.p=null;render()}
 else if(a==="m"){const [i,j]=id.split("_"),m=DATA.missions[i].t[j][2];if(S.done[id]){delete S.done[id];for(const k in m)S.xp[k]=Math.max(0,(S.xp[k]||0)-m[k]);save()}else{S.done[id]=1;award(m)}render()}
 else if(a==="train")startTrain(id);else if(a==="stop")stop();else if(a==="rx")reflex()});
document.addEventListener("change",e=>{if(e.target.id==="tm"){S.p.min=+e.target.value;save();render();return}if(e.target.id==="imp"&&e.target.files[0]){const r=new FileReader();r.onload=()=>{try{Object.assign(S,JSON.parse(r.result));save();render()}catch(x){alert("File sahi nahi hai")}};r.readAsText(e.target.files[0]);return}if(e.target.id!=="ph"||!e.target.files[0])return;const im=new Image();im.onload=()=>{const c=document.createElement("canvas");c.width=320;c.height=im.height*320/im.width;c.getContext("2d").drawImage(im,0,0,c.width,c.height);S.photos.push({d:T(),s:c.toDataURL("image/jpeg",.7)});save();render()};im.src=URL.createObjectURL(e.target.files[0])});
// ---- Reflex drill
function reflex(){const ar=$("#ar"),out=$("#rx");let n=0,ts=[];ar.innerHTML="";
 const next=()=>{if(n>=5){const avg=Math.round(ts.reduce((a,b)=>a+b)/5);out.textContent="Average "+avg+" ms"+(avg<450?" · Reflex +"+Math.round(500/avg*10)+" XP":"");award({reflex:avg<450?Math.round(500/avg*10):2,speed:2});setRank();return}
  ar.innerHTML="";setTimeout(()=>{const t=document.createElement("button");t.style.left=Math.random()*(ar.clientWidth-64)+"px";t.style.top=Math.random()*(ar.clientHeight-64)+"px";const s=performance.now();t.onclick=()=>{ts.push(performance.now()-s);n++;out.textContent="Round "+n+": "+Math.round(ts[n-1])+" ms";next()};ar.appendChild(t)},800+Math.random()*1800)};next()}
// ---- Camera trainer
const ang=(a,b,c)=>{const r=Math.atan2(c.y-b.y,c.x-b.x)-Math.atan2(a.y-b.y,a.x-b.x);const d=Math.abs(r*57.2958);return d>180?360-d:d};
const side=l=>(l[23].visibility+l[25].visibility+l[27].visibility)>(l[24].visibility+l[26].visibility+l[28].visibility)?[11,13,15,23,25,27]:[12,14,16,24,26,28];
function rep(st,v,dn,up,cb){if(v<dn){if(st.ph!=="d"){st.ph="d";st.m=v}st.m=Math.min(st.m,v)}else if(v>up&&st.ph==="d"){st.ph="u";st.reps++;cb(st.m)}}
const CHK={
squat(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);rep(st,ang(h,k,a),100,160,m=>m>110?say("Aur neeche jao",1):say("Shabaash, sahi rep",0));if(st.ph==="d"&&ang(s,h,k)<50)say("Seena upar rakho",1)},
pushup(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);rep(st,ang(s,e,w),95,155,m=>m>105?say("Aur neeche jao",1):say("Sahi rep!",0));if(ang(s,h,a)<158)say("Kamar seedhi rakho",1)},
lunge(l,st,say){rep(st,Math.min(ang(l[23],l[25],l[27]),ang(l[24],l[26],l[28])),105,160,m=>m>115?say("Aur neeche jao",1):say("Badhiya lunge!",0))},
jj(l,st,say){const sw=Math.abs(l[11].x-l[12].x)||.1,up=Math.min(l[15].y,l[16].y)<l[0].y,wide=Math.abs(l[27].x-l[28].x)>1.6*sw;if(up&&wide)st.o=1;else if(st.o&&!up&&!wide){st.o=0;st.reps++}if(up&&!wide)say("Pair aur chaude karo",1);else if(wide&&!up)say("Haath sir ke upar",1)},
plank(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);if(ang(s,h,a)>=165){const n=performance.now();if(st.t0)st.sec+=(n-st.t0)/1000;st.t0=n;st.reps=Math.floor(st.sec);say("Bahut badhiya, hold karo",0)}else{st.t0=0;say("Kamar seedhi rakho",1)}},
punch(l,st,say){const mx=Math.max(ang(l[11],l[13],l[15]),ang(l[12],l[14],l[16]));if(mx>155)st.x=1;else if(mx<100&&st.x){st.x=0;st.reps++;say("Punch! Wapas guard",0)}
 if(mx<100&&(l[15].y+l[16].y)/2>(l[11].y+l[12].y)/2+.05)say("Guard upar rakho",1)},
kick(l,st,say){const hy=(l[23].y+l[24].y)/2,t=Math.abs(hy-(l[11].y+l[12].y)/2)||.2,r=(Math.min(l[27].y,l[28].y)-hy)/t;
 if(r<.4){st.m=Math.min(st.m??9,r);st.h=1}else if(r>1&&st.h){st.h=0;st.reps++;st.m>.1?say("Kick aur upar",1):say("Zabardast kick!",0);st.m=9}}};
let run=null;
function fk(k){const[hx,hy,t,la,lf,ra,rf,lt,ls,rt,rs]=k,R=Math.PI/180,P=(x,y,a,L)=>[x+L*Math.sin(a*R),y+L*Math.cos(a*R)],sh=[hx+28*Math.sin(t*R),hy-28*Math.cos(t*R)],
 le=P(...sh,la,16),re=P(...sh,ra,16),lk=P(hx,hy,lt,22),rk=P(hx,hy,rt,22);
 return {s:[[[hx,hy],sh],[sh,le],[le,P(...le,lf,15)],[sh,re],[re,P(...re,rf,15)],[[hx,hy],lk],[lk,P(...lk,ls,22)],[[hx,hy],rk],[rk,P(...rk,rs,22)]],h:[hx+37*Math.sin(t*R),hy-37*Math.cos(t*R)]}}
function drawRef(ex){const c=$("#rf").getContext("2d"),p=.5-.5*Math.cos(performance.now()/1000*Math.PI),k=ex.kf[0].map((v,i)=>v+(ex.kf[1][i]-v)*p),f=fk(k);
 c.clearRect(0,0,110,110);c.save();c.scale(.9,.9);c.strokeStyle="#b3122a";c.lineWidth=4;c.lineCap="round";f.s.forEach(([a,b])=>{c.beginPath();c.moveTo(...a);c.lineTo(...b);c.stroke()});c.beginPath();c.arc(f.h[0],f.h[1],7,0,6.3);c.stroke();c.restore()}
const BONES=[[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]];
async function startTrain(id){const ex=DATA.ex[id];stop(true);
 $("#v").innerHTML=`<div class="cam"><video id="vid" playsinline muted></video><canvas id="ov"></canvas><canvas id="rf" width="110" height="110"></canvas><div id="cnt">0</div><div id="fb">Camera aur model load ho raha hai…</div></div><h2>${ex.n}</h2><p class="sub">${ex.d}</p><button class="btn w" data-a="stop">Khatam karo</button>`;
 const fb=$("#fb");let spoke=0,last="";
 const say=(t,bad)=>{fb.textContent=t;fb.className=bad?"bad":"good";run.bad=bad;if(t!==last&&performance.now()-spoke>2500&&"speechSynthesis"in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang="en-IN";speechSynthesis.speak(u);spoke=performance.now()}last=t};
 try{const lib=await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/+esm");
  const fs=await lib.FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
  const lm=await lib.PoseLandmarker.createFromOptions(fs,{baseOptions:{modelAssetPath:"https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",delegate:"GPU"},runningMode:"VIDEO",numPoses:1});
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:640,height:480},audio:false}),vid=$("#vid");vid.srcObject=stream;await vid.play();
  run={id,ex,lm,vid,stream,st:{reps:0,sec:0},bad:0,lt:-1};fb.textContent="Poori body camera mein laao";
  const ov=$("#ov"),c=ov.getContext("2d"),chk=CHK[ex.lg||id];
  const loop=()=>{if(!run||run.lm!==lm)return;if(vid.currentTime!==run.lt){run.lt=vid.currentTime;ov.width=vid.videoWidth;ov.height=vid.videoHeight;c.clearRect(0,0,ov.width,ov.height);
   const l=lm.detectForVideo(vid,performance.now()).landmarks[0];
   if(l){const W=ov.width,H=ov.height;c.strokeStyle=run.bad?"#ff5252":"#69f0ae";c.lineWidth=6;c.lineCap="round";BONES.forEach(([a,b])=>{c.beginPath();c.moveTo(l[a].x*W,l[a].y*H);c.lineTo(l[b].x*W,l[b].y*H);c.stroke()});
    c.beginPath();c.arc(l[0].x*W,l[0].y*H,Math.abs(l[11].x-l[12].x)*W*.5,0,6.3);c.stroke();
    if([11,12,23,24].every(i=>l[i].visibility>.4))chk(l,run.st,say);else say("Poori body camera mein laao",1);$("#cnt").textContent=run.st.reps}}
   drawRef(ex);requestAnimationFrame(loop)};loop()
 }catch(e){fb.className="bad";fb.textContent="Camera ya model load nahi hua. Camera permission aur internet check karo.";console.error(e)}}
function stop(quiet){if(!run)return;const r=run;run=null;r.stream&&r.stream.getTracks().forEach(t=>t.stop());try{r.lm.close()}catch(e){}if("speechSynthesis"in window)speechSynthesis.cancel();
 if(r.st.reps>0){const m={};for(const k in r.ex.st)m[k]=r.ex.st[k]*Math.ceil(r.st.reps/(r.ex.u==="sec"?10:5));award(m)}
 if(!quiet){S.tab="train";render()}}

const BD=[["Pehla kadam",()=>total()>0],["3 din streak",()=>S.streak>=3],["7 din streak",()=>S.streak>=7],["30 din streak",()=>S.streak>=30],["500 XP",()=>total()>=500],["2000 XP",()=>total()>=2000],["Rank C",()=>"CBAS".includes(rank())],["Rank S",()=>rank()==="S"],["Photo tracker",()=>S.photos.length>0],["10 active din",()=>Object.keys(S.log).length>=10]];
const badges=()=>`<div class="bd">${BD.map(([n,f])=>`<span class="${f()?"on":""}">${n}</span>`).join("")}</div>`;
const dk=i=>{const d=new Date();d.setDate(d.getDate()-i);return d.toLocaleDateString("en-CA")};
function heat(){let h="";for(let i=83;i>=0;i--){const n=S.log[dk(i)]||0;h+=`<i style="opacity:${n?Math.min(1,.35+n*.12):.12}"></i>`}return `<div class="heat">${h}</div>`}
function report(){let days=0,acts=0;for(let i=0;i<7;i++){const n=S.log[dk(i)]||0;if(n)days++;acts+=n}const top=Object.keys(STATS).sort((a,b)=>(S.xp[b]||0)-(S.xp[a]||0))[0];
 return `<h2>Weekly report</h2><div class="stats"><div class="stat"><b>${days}/7</b><span>ACTIVE DIN</span></div><div class="stat"><b>${acts}</b><span>KAAM</span></div><div class="stat"><b>${total()?STATS[top]:"-"}</b><span>TOP STAT</span></div></div>`}
function more(){const back=`<button class="btn o s" data-a="sub" data-id="">← Wapas</button>`;
 if(S.sub==="looks")return back+looks();
 if(S.sub==="brain")return back+brain();if(S.sub==="cards")return back+cardsV();
 if(S.sub==="height")return back+`<h2>Height tracker</h2><p class="sub">Subah aur raat ek hi jagah deewar par napo. Din bhar spine dabne se 1-2 cm ka farak normal hai. Ye tracker sirf posture sudhaar dekhne ke liye hai.</p><input id="hc" type="number" step="0.1" placeholder="cm" class="card" style="width:100%"><button class="btn w" data-a="hadd">Aaj ki height save karo</button><div style="margin-top:10px">`+(S.hl||[]).slice(-10).reverse().map(x=>`<div class="card row"><span>${x.d}</span><b>${x.h} cm</b></div>`).join("")+`</div>`;
 if(S.sub==="backup")return back+`<h2>Backup</h2><p class="sub">Progress sirf is browser mein save hai. Browser clear karne se pehle backup le lo, aur naye phone par import kar do.</p><button class="btn w" data-a="export">Backup download karo</button><label class="btn o w" style="display:block;text-align:center;margin-top:10px">Backup import karo<input id="imp" type="file" accept="application/json" hidden></label>`;
 const L=(t,d,x)=>`<${x[0]} class="card row" style="width:100%;color:inherit;text-decoration:none;text-align:left;font:inherit" ${x[1]}><div><b>${t}</b><div class="sub">${d}</div></div><span class="sub">›</span></${x[0]}>`;
 return `<h2>Aur features</h2>`+L("Photo progress","Before/after, sirf phone mein",["button",'data-a="sub" data-id="looks"'])+L("Guides aur exercise library","Skincare, posture, neend, exercise steps",["a",'href="guides.html"'])+L("Brain Lab","Memory, focus, flashcards",["button",'data-a="sub" data-id="brain"'])+L("Height tracker","Posture sudhaar napo",["button",'data-a="sub" data-id="height"'])+L("Share card","Rank aur streak ki image",["button",'data-a="share"'])+L("Backup / Restore","Progress ko save ya import karo",["button",'data-a="sub" data-id="backup"'])+L("About aur Contact","Shinka kya hai",["a",'href="about.html"'])+L("Privacy Policy","Data aur camera ke baare mein",["a",'href="privacy.html"'])}
function exp(){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(S)],{type:"application/json"}));a.download="shinka-backup.json";a.click()}
function share(){const c=document.createElement("canvas");c.width=c.height=600;const x=c.getContext("2d");x.fillStyle="#0e0e10";x.fillRect(0,0,600,600);
 x.fillStyle="#d7263d";x.font="700 80px serif";x.fillText("進化",40,110);x.fillStyle="#f2efe9";x.font="700 30px sans-serif";x.fillText("SHINKA",44,160);
 x.fillStyle="#c9a227";x.font="700 190px serif";x.fillText(rank(),44,350);x.fillStyle="#f2efe9";x.font="28px sans-serif";x.fillText(S.streak+" din streak · "+total()+" XP",44,410);
 Object.keys(STATS).sort((a,b)=>(S.xp[b]||0)-(S.xp[a]||0)).slice(0,3).forEach((k,i)=>x.fillText(STATS[k]+"  Lv "+lv(S.xp[k]),44,470+i*40));
 c.toBlob(async b=>{const f=new File([b],"shinka.png",{type:"image/png"});if(navigator.canShare&&navigator.canShare({files:[f]})){try{await navigator.share({files:[f]});return}catch(e){}}const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="shinka.png";a.click()})}
let rt=null;
const speak=t=>{if("speechSynthesis"in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang="en-IN";speechSynthesis.speak(u)}};
function stopRt(){if(rt){clearInterval(rt.iv);rt=null}}
function startRt(k,m){stop(true);stopRt();const R=DATA.routines[k],list=[];let sum=0;for(const id of R.items){const x=DATA.st[id];if(sum+x.s>m*60&&list.length)break;list.push(x);sum+=x.s}
 rt={list,i:0,t:list[0].s,stats:R.stats,label:R.n,iv:setInterval(tickRt,1000)};drawRt()}
function drawRt(){const x=rt.list[rt.i];$("#v").innerHTML=`<div class="card" style="text-align:center"><div class="sub">${rt.label} · ${rt.i+1}/${rt.list.length}</div><h2 style="font:700 26px var(--serif);text-transform:none;letter-spacing:0;color:var(--ink);margin:10px 0">${x.n}</h2><div id="tm2" style="font:700 64px var(--serif);color:var(--acc)">${rt.t}</div><p class="sub">${x.d}</p><div class="bar"><i id="pb" style="width:0"></i></div></div><div class="g"><button class="btn o" data-a="skip">Skip</button><button class="btn" data-a="rtstop">Khatam</button></div>`;speak(x.n)}
function tickRt(){rt.t--;const x=rt.list[rt.i];if(rt.t<=0){rt.i++;if(rt.i>=rt.list.length)return finRt(true);rt.t=rt.list[rt.i].s;return drawRt()}$("#tm2").textContent=rt.t;$("#pb").style.width=(1-rt.t/x.s)*100+"%"}
function finRt(ok){const r=rt;stopRt();if("speechSynthesis"in window)speechSynthesis.cancel();if(ok&&r)award(r.stats);S.tab="home";S.sub="";render();if(ok)$("#v").insertAdjacentHTML("afterbegin",'<div class="card" style="border-color:var(--ok)"><b>Ho gaya!</b> XP mil gaya.</div>')}
let G={};
const stopG=()=>{clearInterval(G.iv);(G.to||[]).forEach(clearTimeout);G={}};
function brain(){const due=(S.cards||[]).filter(c=>c.due<=T()).length,B=S.bs||{};
 const L=(t,d,id)=>`<div class="card row"><div><b>${t}</b><div class="sub">${d}</div></div><button class="btn s" data-a="g" data-id="${id}">Start</button></div>`;
 return `<h2>Brain Lab</h2><p class="sub">"Dimaag ka sirf 10% use hota hai" wali baat mith hai. Memory aur focus ek skill hai, jo sahi techniques, practice, neend aur exercise se behtar hoti hai. Ye games specific skills train karte hain.</p>`+L("Sequence memory","Best: level "+(B.seq||0),"seq")+L("Number memory","Best: "+(B.num||0)+" digits","num")+L("Mental math (60 sec)","Best: "+(B.math||0),"math")+rtBtn("focus",25)+`<div class="card row"><div><b>Flashcards</b><div class="sub">${due} cards aaj review ke liye</div></div><button class="btn s" data-a="sub" data-id="cards">Open</button></div><a class="card row" href="guides/yaadasht.html" style="text-decoration:none;color:inherit"><div><b>Yaadasht badhane ke tareeke</b><div class="sub">Memory palace, spaced repetition</div></div><span class="sub">›</span></a>`}
function startG(k){stopG();G={k,to:[]};if(k==="seq"){G.seq=[];G.lvl=0;nextSeq()}else if(k==="num"){G.n=3;nextNum()}else{G.sc=0;G.t=60;G.iv=setInterval(()=>{G.t--;const e=$("#mt");if(e)e.textContent=G.t;if(G.t<=0)endG(G.sc)},1000);nextQ()}}
function endG(score){const k=G.k,prev=(S.bs||{})[k]||0;stopG();S.bs=S.bs||{};if(score>prev)S.bs[k]=score;award(k==="math"?{focus:score*2,mind:score}:{memory:score*3,focus:score});
 $("#v").innerHTML=`<button class="btn o s" data-a="sub" data-id="brain">← Wapas</button><div class="card" style="text-align:center;margin-top:12px"><div class="sub">Score</div><div style="font:700 56px var(--serif);color:var(--acc)">${score}</div><div class="sub">Best: ${Math.max(prev,score)}</div></div><button class="btn w" data-a="g" data-id="${k}">Dobara</button>`}
function nextSeq(){G.lvl++;G.seq.push(Math.floor(Math.random()*9));G.inp=0;G.lock=true;
 $("#v").innerHTML=`<div class="sub">Level ${G.lvl}. Pattern dekho, phir dohrao.</div><div class="g3">${[...Array(9)].map((_,i)=>`<button class="cell" id="c${i}" data-a="cell" data-id="${i}"></button>`).join("")}</div>`;
 G.seq.forEach((c,i)=>G.to.push(setTimeout(()=>{const e=$("#c"+c);if(e){e.classList.add("lit");G.to.push(setTimeout(()=>e.classList.remove("lit"),400))}},700+i*700)));
 G.to.push(setTimeout(()=>{G.lock=false},700+G.seq.length*700))}
function nextNum(){const n=G.n;G.v=Array.from({length:n},()=>Math.floor(Math.random()*10)).join("");
 $("#v").innerHTML=`<div class="card" style="text-align:center"><div class="sub">${n} digits yaad karo</div><div style="font:700 44px var(--serif);letter-spacing:.2em;margin-top:10px">${G.v}</div></div>`;
 G.to.push(setTimeout(()=>{$("#v").innerHTML=`<div class="card"><div class="sub">Number likho</div><input id="nm" type="text" inputmode="numeric" class="card" style="width:100%;margin:8px 0"><button class="btn w" data-a="nchk">Check</button></div>`;$("#nm").focus()},1000+n*700))}
function nextQ(){const L=1+Math.floor(G.sc/5),r=()=>Math.floor(Math.random()*(9+L*6))+2;let a=r(),b=r();const o=["+","-","×"][Math.floor(Math.random()*3)];
 if(o==="-"&&b>a)[a,b]=[b,a];if(o==="×"){b=b%10+2}G.ans=o==="+"?a+b:o==="-"?a-b:a*b;
 $("#v").innerHTML=`<div class="card" style="text-align:center"><div class="sub">Time: <span id="mt">${G.t}</span>s · Score ${G.sc}</div><div style="font:700 44px var(--serif);margin:12px 0">${a} ${o} ${b}</div><input id="mi" type="text" inputmode="numeric" class="card" style="width:100%;margin-bottom:8px"><button class="btn w" data-a="mchk">Check</button></div>`;$("#mi").focus()}
function cardsV(){const C=S.cards=S.cards||[],due=C.filter(c=>c.due<=T());
 return `<h2>Flashcards</h2><p class="sub">Spaced repetition: jo yaad hai wo der se aata hai, jo bhoola wo jaldi. Isse cheezein lambe samay tak yaad rehti hain.</p><button class="btn w" data-a="rev" ${due.length?"":"disabled"}>Review shuru karo (${due.length} due)</button><h2>Naya card</h2><input id="cq" class="card" style="width:100%;margin-bottom:8px" placeholder="Sawaal / shabd"><input id="ca" class="card" style="width:100%;margin-bottom:8px" placeholder="Jawab"><button class="btn o w" data-a="cadd">Add karo</button><h2>Total ${C.length} cards</h2>`+C.slice(-8).reverse().map(c=>`<div class="card sub">${c.q} → ${c.a}</div>`).join("")}
function review(){G={k:"rev",q:(S.cards||[]).filter(c=>c.due<=T()),i:0,ok:0,to:[]};revNext()}
function revNext(){if(G.i>=G.q.length){const ok=G.ok,n=G.q.length;stopG();award({memory:ok*2+n});S.sub="cards";render();return}const c=G.q[G.i];
 $("#v").innerHTML=`<div class="sub">${G.i+1}/${G.q.length}</div><div class="card" style="text-align:center;font:700 26px var(--serif);padding:30px 10px">${c.q}</div><div id="ans"></div><button class="btn w" data-a="show">Jawab dikhao</button>`}
render();
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
