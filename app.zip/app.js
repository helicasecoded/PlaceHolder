import {DATA} from "./data.js";
const $=s=>document.querySelector(s),KEY="alagdikho_v2",T=()=>new Date().toLocaleDateString("en-CA");
const STATS={speed:"Speed",reflex:"Reflex",agility:"Agility",strength:"Strength",power:"Power",endurance:"Endurance",combat:"Combat",looks:"Looks",talk:"Talk",mind:"Mind"};
let S={p:null,xp:{},streak:0,last:"",day:"",done:{},photos:[],best:0,tab:"home"};
try{Object.assign(S,JSON.parse(localStorage.getItem(KEY)||"{}"))}catch(e){}
if(S.day!==T()){S.day=T();S.done={}}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const lv=x=>Math.floor(Math.sqrt((x||0)/20))+1;
const rank=()=>{const a=Object.keys(STATS).reduce((s,k)=>s+lv(S.xp[k]),0)/10;return a<1.6?"E":a<2.2?"D":a<3?"C":a<4?"B":a<5.5?"A":"S"};
function award(m){const b={speed:["speed","reflex","agility"],strength:["strength","power","endurance","combat"]}[S.p&&S.p.path]||[];
 for(const k in m)S.xp[k]=(S.xp[k]||0)+Math.round(m[k]*(b.includes(k)?1.25:1));
 if(S.last!==T()){const y=new Date();y.setDate(y.getDate()-1);S.streak=S.last===y.toLocaleDateString("en-CA")?S.streak+1:1;S.last=T()}save()}
function plan(d){const map={1:0,2:1,4:2,5:3,6:4};if(!(d in map))return null;const m=[1,1.5,2][S.p.level];
 let ids=[...DATA.goals[S.p.goal][1][map[d]]];if(S.p.path==="speed")ids.push("jj");if(S.p.path==="strength")ids.push("pushup");
 return [...new Set(ids)].map(id=>({id,n:Math.round(DATA.ex[id].reps*m)}))}
const exBtn=(x)=>`<div class="card row"><div><b>${DATA.ex[x.id].n}</b><div class="sub">${x.n} ${DATA.ex[x.id].u}</div></div><button class="btn s" data-a="train" data-id="${x.id}">Start</button></div>`;
const IC={home:'<path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z"/>',plan:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',train:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',missions:'<path d="M5 12l5 5L20 7"/>',stats:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',looks:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>'};
const TABS=[["home","Home"],["plan","Plan"],["train","Train"],["missions","Missions"],["stats","Stats"],["looks","Looks"]];
const setRank=()=>{$("#rk").innerHTML=S.p?`<span>RANK</span><b>${rank()}</b>`:""};
function render(){
 $("#tb").innerHTML=TABS.map(([k,n])=>`<button data-a="tab" data-id="${k}" class="${S.tab===k?"on":""}"><svg viewBox="0 0 24 24">${IC[k]}</svg>${n}</button>`).join("");
 setRank();
 const v=$("#v");if(!S.p){v.innerHTML=onboard();return}
 v.innerHTML=({home,plan:planV,train,missions,stats,looks})[S.tab]();
 if(S.tab==="stats")radar()}
function onboard(){const o=(o)=>Object.entries(o).map(([k,n])=>`<option value="${k}">${n}</option>`).join("");
 return `<div class="hero"><span class="kj">進化</span><h2>Shinka: roz thoda evolve karo</h2><p class="sub">Body, looks, baat-cheet aur dimaag, sab ek jagah. Pehle apna goal chuno, uske hisaab se plan banega.</p></div><div class="card" style="margin-top:16px">
 <label>Body goal<select id="g">${o(Object.fromEntries(Object.entries(DATA.goals).map(([k,g])=>[k,g[0]])))}</select></label>
 <label>Level<select id="l"><option value="0">Beginner</option><option value="1">Intermediate</option><option value="2">Advanced</option></select></label>
 <label>Path<select id="pa"><option value="bal">Balanced</option><option value="speed">Speed path (speed, reflex, agility)</option><option value="strength">Strength path (strength, power, combat)</option></select></label>
 <p class="sub">Dard ya chot ho to ruk jao aur doctor se poocho. Ye app doctor ya coach ki jagah nahi leta.</p>
 <button class="btn w" data-a="start">Shuru karo</button></div>`}
function home(){const p=plan(new Date().getDay()),all=DATA.missions.flatMap((c,i)=>c.t.map((_,j)=>i+"_"+j)),dn=all.filter(k=>S.done[k]).length;
 return `<div class="stats"><div class="stat"><b>${S.streak}</b><span>DIN STREAK</span></div><div class="stat"><b>${dn}/${all.length}</b><span>MISSIONS</span></div><div class="stat"><b>${Object.values(S.xp).reduce((a,b)=>a+b,0)}</b><span>TOTAL XP</span></div></div>
 <h2>Aaj ka workout</h2>${p?p.map(exBtn).join(""):'<div class="card">Aaj rest day. 10 min stretching aur khoob paani.</div>'}
 <h2>Stand-out challenge</h2><div class="card">${DATA.challenges[new Date().getDay()]}</div>`}
function planV(){const names=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
 return `<h2>${DATA.goals[S.p.goal][0]}: hafte ka plan</h2>`+[1,2,3,4,5,6,0].map(d=>{const p=plan(d);return `<div class="card"><b>${names[d]}</b><div class="sub">${p?p.map(x=>DATA.ex[x.id].n+" "+x.n).join(", "):"Rest + stretching"}</div></div>`}).join("")+`<button class="btn o w" data-a="redo">Goal badlo</button>`}
function train(){return `<h2>Camera trainer</h2><p class="sub">Phone 2-3 meter door, poori body dikhe. Video phone se bahar nahi jaati.</p>`+Object.keys(DATA.ex).map(id=>exBtn({id,n:DATA.ex[id].reps})).join("")+
 `<h2>Reflex drill</h2><div class="card"><div id="rx" class="sub">5 round. Hara circle dikhte hi tap karo.</div><div id="ar" class="tgt"></div><button class="btn w" data-a="rx">Start</button></div>`}
function missions(){return DATA.missions.map((c,i)=>`<h2>${c.n}</h2>`+c.t.map((t,j)=>{const k=i+"_"+j,d=S.done[k];return `<button class="task ${d?"done":""}" data-a="m" data-id="${k}"><span class="box">${d?"✓":""}</span><span><b>${t[0]}</b><div class="sub">${t[1]}</div></span></button>`}).join("")).join("")}
function stats(){return `<h2>Tumhare stats</h2><canvas id="rd" width="320" height="300" style="width:100%"></canvas>`+Object.entries(STATS).map(([k,n])=>`<div class="card"><div class="row"><b>${n}</b><span>Lv ${lv(S.xp[k])} · ${S.xp[k]||0} XP</span></div><div class="bar"><i style="width:${Math.min(100,((S.xp[k]||0)%(20*lv(S.xp[k])**2))/(20*(2*lv(S.xp[k])+1))*100)}%"></i></div></div>`).join("")}
function radar(){const c=$("#rd").getContext("2d"),ks=Object.keys(STATS),cx=160,cy=150,R=100,col=getComputedStyle(document.body).color;c.strokeStyle=col;c.fillStyle=col;c.globalAlpha=.25;
 for(let r=1;r<=4;r++){c.beginPath();ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571;c.lineTo(cx+R*r/4*Math.cos(a),cy+R*r/4*Math.sin(a))});c.closePath();c.stroke()}
 c.globalAlpha=1;c.font="11px system-ui";c.textAlign="center";ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571;c.fillText(STATS[k],cx+(R+22)*Math.cos(a),cy+(R+22)*Math.sin(a)+4)});
 c.beginPath();ks.forEach((k,i)=>{const a=i/ks.length*6.283-1.571,r=R*Math.min(1,lv(S.xp[k])/10);c.lineTo(cx+r*Math.cos(a),cy+r*Math.sin(a))});c.closePath();c.fillStyle="rgba(215,38,61,.35)";c.fill();c.strokeStyle="#d7263d";c.lineWidth=2;c.stroke()}
function looks(){return `<h2>Photo progress</h2><p class="sub">Photos sirf is phone mein save hoti hain. Har 30 din mein ek photo lo, same light aur same angle.</p>
 <label class="btn w" style="display:block;text-align:center">Photo add karo<input id="ph" type="file" accept="image/*" hidden></label>
 <div class="g" style="margin-top:10px">${S.photos.map(p=>`<div><img class="ph" src="${p.s}" alt=""><div class="sub">${p.d}</div></div>`).join("")}</div>`}
document.addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(!b)return;const a=b.dataset.a,id=b.dataset.id;
 if(a==="tab"){stop(true);S.tab=id;save();render()}
 else if(a==="start"){S.p={goal:$("#g").value,level:+$("#l").value,path:$("#pa").value};save();render()}
 else if(a==="redo"){S.p=null;render()}
 else if(a==="m"){const [i,j]=id.split("_"),m=DATA.missions[i].t[j][2];if(S.done[id]){delete S.done[id];for(const k in m)S.xp[k]=Math.max(0,(S.xp[k]||0)-m[k]);save()}else{S.done[id]=1;award(m)}render()}
 else if(a==="train")startTrain(id);else if(a==="stop")stop();else if(a==="rx")reflex()});
document.addEventListener("change",e=>{if(e.target.id!=="ph"||!e.target.files[0])return;const im=new Image();im.onload=()=>{const c=document.createElement("canvas");c.width=320;c.height=im.height*320/im.width;c.getContext("2d").drawImage(im,0,0,c.width,c.height);S.photos.push({d:T(),s:c.toDataURL("image/jpeg",.7)});save();render()};im.src=URL.createObjectURL(e.target.files[0])});
// ---- Reflex drill
function reflex(){const ar=$("#ar"),out=$("#rx");let n=0,ts=[];ar.innerHTML="";
 const next=()=>{if(n>=5){const avg=Math.round(ts.reduce((a,b)=>a+b)/5);out.textContent="Average "+avg+" ms"+(avg<450?" · Reflex +"+Math.round(500/avg*10)+" XP":"");award({reflex:avg<450?Math.round(500/avg*10):2,speed:2});setRank();return}
  ar.innerHTML="";setTimeout(()=>{const t=document.createElement("button");t.style.left=Math.random()*(ar.clientWidth-64)+"px";t.style.top=Math.random()*(ar.clientHeight-64)+"px";const s=performance.now();t.onclick=()=>{ts.push(performance.now()-s);n++;out.textContent="Round "+n+": "+Math.round(ts[n-1])+" ms";next()};ar.appendChild(t)},800+Math.random()*1800)};next()}
// ---- Camera trainer
const ang=(a,b,c)=>{const r=Math.atan2(c.y-b.y,c.x-b.x)-Math.atan2(a.y-b.y,a.x-b.x);const d=Math.abs(r*57.2958);return d>180?360-d:d};
const side=l=>(l[23].visibility+l[25].visibility+l[27].visibility)>(l[24].visibility+l[26].visibility+l[28].visibility)?[11,13,15,23,25,27]:[12,14,16,24,26,28];
function rep(st,v,dn,up,cb){if(v<dn){if(st.ph!=="d"){st.ph="d";st.m=v}st.m=Math.min(st.m,v)}else if(v>up&&st.ph==="d"){st.ph="u";st.reps++;cb(st.m)}}
const CHK={
squat(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);rep(st,ang(h,k,a),100,160,m=>m>110?say("Aur neeche jao",1):say("Shabaash, sahi rep",0));if(st.ph==="d"&&ang(s,h,k)<50)say("Seena upar rakho",1)},
pushup(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);rep(st,ang(s,e,w),95,155,m=>m>105?say("Aur neeche jao",1):say("Sahi rep!",0));if(ang(s,h,a)<158)say("Kamar seedhi rakho",1)},
lunge(l,st,say){rep(st,Math.min(ang(l[23],l[25],l[27]),ang(l[24],l[26],l[28])),105,160,m=>m>115?say("Aur neeche jao",1):say("Badhiya lunge!",0))},
jj(l,st,say){const sw=Math.abs(l[11].x-l[12].x)||.1,up=Math.min(l[15].y,l[16].y)<l[0].y,wide=Math.abs(l[27].x-l[28].x)>1.6*sw;if(up&&wide)st.o=1;else if(st.o&&!up&&!wide){st.o=0;st.reps++}if(up&&!wide)say("Pair aur chaude karo",1);else if(wide&&!up)say("Haath sir ke upar",1)},
plank(l,st,say){const[s,e,w,h,k,a]=side(l).map(i=>l[i]);if(ang(s,h,a)>=165){const n=performance.now();if(st.t0)st.sec+=(n-st.t0)/1000;st.t0=n;st.reps=Math.floor(st.sec);say("Bahut badhiya, hold karo",0)}else{st.t0=0;say("Kamar seedhi rakho",1)}},
punch(l,st,say){const mx=Math.max(ang(l[11],l[13],l[15]),ang(l[12],l[14],l[16]));if(mx>155)st.x=1;else if(mx<100&&st.x){st.x=0;st.reps++;say("Punch! Wapas guard",0)}
 if(mx<100&&(l[15].y+l[16].y)/2>(l[11].y+l[12].y)/2+.05)say("Guard upar rakho",1)},
kick(l,st,say){const hy=(l[23].y+l[24].y)/2,t=Math.abs(hy-(l[11].y+l[12].y)/2)||.2,r=(Math.min(l[27].y,l[28].y)-hy)/t;
 if(r<.4){st.m=Math.min(st.m??9,r);st.h=1}else if(r>1&&st.h){st.h=0;st.reps++;st.m>.1?say("Kick aur upar",1):say("Zabardast kick!",0);st.m=9}}};
let run=null;
function fk(k){const[hx,hy,t,la,lf,ra,rf,lt,ls,rt,rs]=k,R=Math.PI/180,P=(x,y,a,L)=>[x+L*Math.sin(a*R),y+L*Math.cos(a*R)],sh=[hx+28*Math.sin(t*R),hy-28*Math.cos(t*R)],
 le=P(...sh,la,16),re=P(...sh,ra,16),lk=P(hx,hy,lt,22),rk=P(hx,hy,rt,22);
 return {s:[[[hx,hy],sh],[sh,le],[le,P(...le,lf,15)],[sh,re],[re,P(...re,rf,15)],[[hx,hy],lk],[lk,P(...lk,ls,22)],[[hx,hy],rk],[rk,P(...rk,rs,22)]],h:[hx+37*Math.sin(t*R),hy-37*Math.cos(t*R)]}}
function drawRef(ex){const c=$("#rf").getContext("2d"),p=.5-.5*Math.cos(performance.now()/1000*Math.PI),k=ex.kf[0].map((v,i)=>v+(ex.kf[1][i]-v)*p),f=fk(k);
 c.clearRect(0,0,110,110);c.save();c.scale(.9,.9);c.strokeStyle="#b3122a";c.lineWidth=4;c.lineCap="round";f.s.forEach(([a,b])=>{c.beginPath();c.moveTo(...a);c.lineTo(...b);c.stroke()});c.beginPath();c.arc(f.h[0],f.h[1],7,0,6.3);c.stroke();c.restore()}
const BONES=[[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]];
async function startTrain(id){const ex=DATA.ex[id];stop(true);
 $("#v").innerHTML=`<div class="cam"><video id="vid" playsinline muted></video><canvas id="ov"></canvas><canvas id="rf" width="110" height="110"></canvas><div id="cnt">0</div><div id="fb">Camera aur model load ho raha hai…</div></div><h2>${ex.n}</h2><p class="sub">${ex.d}</p><button class="btn w" data-a="stop">Khatam karo</button>`;
 const fb=$("#fb");let spoke=0,last="";
 const say=(t,bad)=>{fb.textContent=t;fb.className=bad?"bad":"good";run.bad=bad;if(t!==last&&performance.now()-spoke>2500&&"speechSynthesis"in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang="en-IN";speechSynthesis.speak(u);spoke=performance.now()}last=t};
 try{const lib=await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/+esm");
  const fs=await lib.FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
  const lm=await lib.PoseLandmarker.createFromOptions(fs,{baseOptions:{modelAssetPath:"https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",delegate:"GPU"},runningMode:"VIDEO",numPoses:1});
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:640,height:480},audio:false}),vid=$("#vid");vid.srcObject=stream;await vid.play();
  run={id,ex,lm,vid,stream,st:{reps:0,sec:0},bad:0,lt:-1};fb.textContent="Poori body camera mein laao";
  const ov=$("#ov"),c=ov.getContext("2d"),chk=CHK[ex.lg||id];
  const loop=()=>{if(!run||run.lm!==lm)return;if(vid.currentTime!==run.lt){run.lt=vid.currentTime;ov.width=vid.videoWidth;ov.height=vid.videoHeight;c.clearRect(0,0,ov.width,ov.height);
   const l=lm.detectForVideo(vid,performance.now()).landmarks[0];
   if(l){const W=ov.width,H=ov.height;c.strokeStyle=run.bad?"#ff5252":"#69f0ae";c.lineWidth=6;c.lineCap="round";BONES.forEach(([a,b])=>{c.beginPath();c.moveTo(l[a].x*W,l[a].y*H);c.lineTo(l[b].x*W,l[b].y*H);c.stroke()});
    c.beginPath();c.arc(l[0].x*W,l[0].y*H,Math.abs(l[11].x-l[12].x)*W*.5,0,6.3);c.stroke();
    if([11,12,23,24].every(i=>l[i].visibility>.4))chk(l,run.st,say);else say("Poori body camera mein laao",1);$("#cnt").textContent=run.st.reps}}
   drawRef(ex);requestAnimationFrame(loop)};loop()
 }catch(e){fb.className="bad";fb.textContent="Camera ya model load nahi hua. Camera permission aur internet check karo.";console.error(e)}}
function stop(quiet){if(!run)return;const r=run;run=null;r.stream&&r.stream.getTracks().forEach(t=>t.stop());try{r.lm.close()}catch(e){}if("speechSynthesis"in window)speechSynthesis.cancel();
 if(r.st.reps>0){const m={};for(const k in r.ex.st)m[k]=r.ex.st[k]*Math.ceil(r.st.reps/(r.ex.u==="sec"?10:5));award(m)}
 if(!quiet){S.tab="train";render()}}
render();
